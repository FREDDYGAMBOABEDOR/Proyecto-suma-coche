public class Main {
    public static void main(String[] args) {
        suma(5, 7, 8 );
        /*int valor1 = 5;
        int valor2 = 7;
        int valor3 = 10;*/
        coche Micoche = new coche();
        Micoche.AumPuertas();

        System.out.println("El coche tiene " + Micoche.puertas + " puerta");

        

    }

    public static void suma(int a, int b, int c) {
        int resul = a + b + c ;

        System.out.println( "La suma es " + resul);

    }
}
class coche {
    public int puertas = 0;
    public void AumPuertas (){
        this.puertas++;
    }
}





